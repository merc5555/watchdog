#! /usr/bin/env python
# -*- coding: utf-8 -*-
####################
# Indigo Watchdog plugin
# Copyright (c) 2017-2022 Alan Carter. All rights reserved.
#

################################################################################
# Imports
################################################################################
import datetime
import time


################################################################################
class Plugin(indigo.PluginBase):
    ########################################
    # Class properties
    ########################################
    def __init__(self, pluginId, pluginDisplayName, pluginVersion, pluginPrefs):
        indigo.PluginBase.__init__(self, pluginId, pluginDisplayName, pluginVersion, pluginPrefs)
        self.deviceList = self.pluginPrefs.get("deviceList", indigo.Dict())
        self.deviceHealth = self.pluginPrefs.get("deviceHealth", {})
        self.devicePriority = self.pluginPrefs.get("devicePriority", {})
        self.deviceNames = self.pluginPrefs.get("deviceNames", {})
        self.push = self.pluginPrefs.get("enablePush", False)
        self.pushDev = self.pluginPrefs.get("pushDev", "")
        self.prowl = self.pluginPrefs.get("enableProwl", False)
        self.mail = self.pluginPrefs.get("enableMail", False)
        self.mailAdd = self.pluginPrefs.get("notificationEmail", "")
        self.reminders = self.pluginPrefs.get("enableReminders", False)
        self.reminderHour = int(self.pluginPrefs.get("reminderHour", 8))
        self.ipMonitoring = self.pluginPrefs.get("enableIpMonitoring", False)
        self.autoDelete = self.pluginPrefs.get("autoDelete", False)
        self.sendReminder = False
        self.reminderNotSent = False
        self.language = int(self.pluginPrefs.get("language", 0))
        self.dst = ""
        self.almostAnHour = datetime.timedelta(minutes=58)
        self.lastCheckTime = datetime.datetime.now()
        self.ipDeviceList = self.pluginPrefs.get("ipDeviceList", indigo.Dict())
        self.ipDeviceNames = self.pluginPrefs.get("ipDeviceNames", {})
        self.pushTimeoutText = ("watchdog has timed out", "Watchdog Timer abgelaufen")
        self.pushHealthyText = ("watchdog is now healthy", "Watchdog ist wieder funktionsfähig")
        self.pushReminderText = ("Reminder: %s timed out at %s", "Erinnerung: %s abgelaufen um %s")
        self.pushTitleText = ("Watchdog Alert", "Watchdog Alarm")
        self.emailHealthyTitleText = ("Indigo: %s Watchdog Healthy", "Indigo: %s Watchdog ist wieder funktionsfähig")
        self.emailTimeoutTitleText = ("Indigo: %s Watchdog Timed Out", "Indigo: %s Watchdog Timer abgelaufen")
        self.logLanguageText = ("Notifications will be sent in English", "Notifications will be sent in German")
        self.appToken = "a1eFMqeieVE3YknCBdw7WfJ7tfMm35"

    ########################################
    def __del__(self):
        indigo.PluginBase.__del__(self)

    ########################################
    def startup(self):
        indigo.server.log("Starting Watchdog plugin")
        for device in self.deviceList:
            self.deviceHealth[device] = 1
        if bool(time.localtime().tm_isdst):
            self.dst = "DST"
            indigo.server.log("Daylight Saving Time is active")
        else:
            self.dst = "GMT"
            indigo.server.log("Daylight Saving Time is inactive")
        if self.push:
            indigo.server.log("Watchdog failure messages will be sent to Pushover device "+self.pushDev)
        if self.prowl:
            indigo.server.log("Watchdog failure messages will be sent using Prowl")
        if self.mail:
            indigo.server.log("Watchdog failure messages will be emailed to "+self.mailAdd)
        if self.reminders:
            indigo.server.log("Daily reminder messages will be sent at %02d00" % self.reminderHour)
        if self.autoDelete:
            indigo.server.log("Monitored devices not found in database will be removed automatically from the Watchdog list")
        else:
            indigo.server.log("Auto-deletion is disabled; devices deleted from Indigo must be removed manually from the Watchdog list")
        fingPlugin = indigo.server.getPlugin('com.karlwachs.fingscan')
        if self.ipMonitoring and not fingPlugin.isEnabled():
            indigo.server.log("fingscan plugin not found.  IP devices will not be monitored")
            self.ipMonitoring = False
        self.startup = True

    def deviceStartComm(self, dev):
        dev.stateListOrDisplayStateIdChanged()
        return

    def shutdown(self):
        indigo.server.log("Stopping Watchdog plugin")
        # Store lists of monitored devices and notification priorities.
        # Device health lists are built dynamically
        # so do not need to be stored in Preferences.
        self.pluginPrefs["deviceList"] = self.deviceList
        self.pluginPrefs["devicePriority"] = self.devicePriority
        self.pluginPrefs["deviceNames"] = self.deviceNames
        self.pluginPrefs["ipDeviceList"] = self.ipDeviceList
        self.pluginPrefs["ipDeviceNames"] = self.ipDeviceNames


    ########################################
    def runConcurrentThread(self):
        indigo.server.log("Starting Watchdog monitoring thread")
        dc = len(self.deviceList)
        ic = len(self.ipDeviceList)
        indigo.server.log("Currently monitoring %d Indigo device%s and %d IP device%s\n" % (dc, "s"[dc == 1:], ic, "s"[ic == 1:]))
        try:
            while True:
                if not self.clocksHaveChanged():
                    now = datetime.datetime.now()
                    if (int(now.hour) == self.reminderHour) and (int(now.minute) == 0) and self.reminders:
                        self.sendReminder = True
                    self.checkDevices()
                    if self.ipMonitoring:
                        self.checkIpDevices()
                self.sleep(60)

        except self.StopThread:
            pass

    ########################################
    # Called when user prefs are changed

    def closedPrefsConfigUi(self, valuesDict, userCancelled):
        # If the user saved preferences, update logging parameters
        if userCancelled == False:
            oldPDev = self.pushDev
            self.pushDev = valuesDict.get("pushDev", "")
            if (self.pushDev != oldPDev) and (self.pushDev != ""):
                indigo.server.log("Pushover device = "+self.pushDev)
            elif (self.pushDev != oldPDev) and (self.pushDev == ""):
                indigo.server.log("Pushover messages will be sent to all devices")
            oldPush = self.push
            self.push = valuesDict.get("enablePush", False)
            if self.push != oldPush:
                if self.push and (self.pushDev != ""):
                    indigo.server.log("Watchdog failure messages will be sent to Pushover device "+self.pushDev)
                elif self.push and (self.pushDev == ""):
                    indigo.server.log("Watchdog failure messages will be sent to all Pushover devices")
                else:
                    indigo.server.log("Watchdog failure messages will not be sent via Pushover")
            oldProwl = self.prowl
            self.prowl = valuesDict.get("enableProwl", False)
            if self.prowl != oldProwl:
                if self.prowl:
                    indigo.server.log("Watchdog failure messages will be sent using Prowl")
                else:
                    indigo.server.log("Watchdog failure messages will not be sent via Prowl")
            oldMailAdd = self.mailAdd
            oldMail = self.mail
            self.mail = valuesDict.get("enableMail", False)
            self.mailAdd = valuesDict.get("notificationEmail", "")
            if self.mail and (self.mailAdd != oldMailAdd) and (self.mailAdd != ""):
                indigo.server.log("Watchdog failure messages will be emailed to "+self.mailAdd)
            elif self.mail != oldMail:
                if self.mail:
                    indigo.server.log("Watchdog failure messages will be emailed to "+self.mailAdd)
                else:
                    indigo.server.log("Watchdog failure messages will not be sent via email")
            oldrem = self.reminders
            self.reminders = valuesDict.get("enableReminders", False)
            if self.reminders != oldrem:
                if self.reminders:
                    indigo.server.log("Daily reminder messages will be sent")
                else:
                    indigo.server.log("Daily reminder messages will not be sent")
            oldhour = int(self.reminderHour)
            self.reminderHour = int(valuesDict.get("reminderHour", 8))
            if self.reminderHour != oldhour:
                indigo.server.log("Daily reminder messages will be sent at %02d00" % self.reminderHour)
            oldlang = self.language
            self.language = int(valuesDict.get("language", 0))
            if self.language != oldlang:
                indigo.server.log(self.logLanguageText[self.language])
            oldIp = self.ipMonitoring
            self.ipMonitoring = valuesDict.get("enableIpMonitoring")
            if self.ipMonitoring != oldIp:
                if self.ipMonitoring:
                    indigo.server.log("IP devices will be monitored for address changes")
                else:
                    indigo.server.log("IP devices will not be monitored")



    ########################################
    # Watchdog specific functions
    ##############################

    def checkDevices(self):
        devCount = 0
        for device in self.deviceList:
            try:
                dev = indigo.devices[int(device[1:])]
                deviceFound = True
                devCount += 1
            except:
                deviceFound = False
            if deviceFound:
                self.deviceNames[device] = dev.name
                timeoutPeriod = datetime.timedelta(minutes=int(self.deviceList[device]))
                if (datetime.datetime.now() - dev.lastChanged) >= timeoutPeriod:
                    if self.deviceHealth[device] == 1 or self.sendReminder:
                        if self.sendReminder:
                            message = self.pushReminderText[self.language] % (dev.name, str(dev.lastChanged + timeoutPeriod))
                        else:
                            message = "%s " % dev.name + self.pushTimeoutText[self.language]
                        if self.startup:
                            errorState = False
                        else:
                            errorState = True
                        indigo.server.log(message, isError=errorState)
                        self.deviceHealth[device] = 0
                        self.devicePriority[device] = self.devicePriority[device] if device in self.devicePriority else 0
                        priority = int(self.devicePriority[device])
                        if not self.startup:
                            if self.push:
                                # Send Pushover notification
                                alertPlugin = indigo.server.getPlugin('io.thechad.indigoplugin.pushover')
                                if alertPlugin.isEnabled():
                                    if priority < 2:
                                        alertProps = {'appToken': self.appToken, 'msgTitle':self.pushTitleText[self.language], 'msgBody':message, 'msgSound':'pushover', 'msgPriority':priority, 'msgDevice':self.pushDev, 'msgSupLinkUrl':'', 'msgSupLinkTitle':''}
                                    else:
                                        alertProps = {'appToken': self.appToken, 'msgTitle':self.pushTitleText[self.language], 'msgBody':message, 'msgSound':'pushover', 'msgPriority':priority, 'retry': 900, 'expire':7200, 'msgDevice':self.pushDev, 'msgSupLinkUrl':'', 'msgSupLinkTitle':''}
                                    alertPlugin.executeAction("send", props=alertProps)
                                else:
                                    indigo.server.log('Watchdog : Pushover plugin not available or Pushover device not specified', isError=True)
                            if self.prowl:
                                # Send Prowl notification
                                alertPlugin = indigo.server.getPlugin('com.heddings.indigo.prowl')
                                if alertPlugin.isEnabled():
                                    alertProps = {'title':self.pushTitleText[self.language], 'message':message, 'priority':priority}
                                    alertPlugin.executeAction("notify", props=alertProps)
                                else:
                                    indigo.server.log('Watchdog : Prowl plugin not available', isError=True)
                            if self.mail and self.mailAdd != "":
                                # Send email notification
                                emailTitle = self.emailTimeoutTitleText[self.language] % dev.name
                                indigo.server.sendEmailTo(self.mailAdd, subject=emailTitle, body=message)
                else:
                    if self.deviceHealth[device] == 0:
                        self.deviceHealth[device] = 1
                        self.devicePriority[device] = self.devicePriority[device] if device in self.devicePriority else 0
                        priority = int(self.devicePriority[device])
                        message = "%s " % dev.name + self.pushHealthyText[self.language]
                        indigo.server.log(dev.name+" watchdog is now healthy")
                        if not self.startup:
                            if self.push:
                                # Send Pushover notification
                                try:
                                    alertPlugin = indigo.server.getPlugin('io.thechad.indigoplugin.pushover')
                                    if alertPlugin.isEnabled():
                                        if priority < 2:
                                            alertProps = {'appToken': self.appToken, 'msgTitle':self.pushTitleText[self.language], 'msgBody':message, 'msgSound':'pushover', 'msgPriority':priority, 'msgDevice':self.pushDev, 'msgSupLinkUrl':'', 'msgSupLinkTitle':''}
                                        else:
                                            alertProps = {'appToken': self.appToken, 'msgTitle':self.pushTitleText[self.language], 'msgBody':message, 'msgSound':'pushover', 'msgPriority':priority, 'retry': 900, 'expire':7200, 'msgDevice':self.pushDev, 'msgSupLinkUrl':'', 'msgSupLinkTitle':''}
                                        alertPlugin.executeAction("send", props=alertProps)
                                    else:
                                        indigo.server.log('Watchdog : Pushover plugin not available or Pushover device not specified', isError=True)
                                except:
                                    indigo.server.log("Pushover send error")
                            if self.prowl:
                                # Send Prowl notification
                                try:
                                    alertPlugin = indigo.server.getPlugin('com.heddings.indigo.prowl')
                                    if alertPlugin.isEnabled():
                                        alertProps = {'title':self.pushTitleText[self.language], 'message':message, 'priority':priority}
                                        alertPlugin.executeAction("notify", props=alertProps)
                                    else:
                                        indigo.server.log('Watchdog : Prowl plugin not available', isError=True)
                                except:
                                    indigo.server.log("Prowl send error")
                            if self.mail and self.mailAdd != "":
                                # Send email notification
                                try:
                                    emailTitle = self.emailHealthyTitleText[self.language] % dev.name
                                    indigo.server.sendEmailTo(self.mailAdd, subject=emailTitle, body=message)
                                except:
                                    indigo.server.log("Email send error")
            else:
                if self.autoDelete:
                    indigo.server.log("Device %s not found - deleting from Watchdog list" % device[1:], isError=True)
                    del self.deviceList[device]
                    try:
                        del self.deviceHealth[device]
                    except:
                        pass
                    try:
                        del self.devicePriority[device]
                    except:
                        pass
                    try:
                        del self.deviceNames[device]
                    except:
                        pass
                else:
                    indigo.server.log("Device %s (%s) not found" % (device[1:], self.deviceNames[device]), isError=True)
        if self.startup:
            self.startup = False
        if self.sendReminder:
            self.sendReminder = False
        if devCount == 0:
            indigo.server.log("No monitored devices found!", isError=True)


    def checkIpDevices(self):
        for device in self.ipDeviceList:
            try:
                dev = indigo.devices[int(device[1:])]
                deviceFound = True
            except:
                deviceFound = False
            if deviceFound:
                self.ipDeviceNames[device] = dev.name
                oldIp = self.ipDeviceList[device]
                newIp = dev.states["ipNumber"]
                if newIp != oldIp:
                    self.ipDeviceList[device] = newIp
                    title = "Watchdog IP Alert"
                    message = "%s IP address has changed from %s to %s" % (dev.name, oldIp, newIp)
                    priority = 0
                    indigo.server.log(message)
                    if not self.startup:
                        if self.push:
                            # Send Pushover notification
                            try:
                                alertPlugin = indigo.server.getPlugin('io.thechad.indigoplugin.pushover')
                                if alertPlugin.isEnabled():
                                    if priority < 2:
                                        alertProps = {'appToken': self.appToken, 'msgTitle':title, 'msgBody':message, 'msgSound':'pushover', 'msgPriority':priority, 'msgDevice':self.pushDev, 'msgSupLinkUrl':'', 'msgSupLinkTitle':''}
                                    else:
                                        alertProps = {'appToken': self.appToken, 'msgTitle':title, 'msgBody':message, 'msgSound':'pushover', 'msgPriority':priority, 'retry': 900, 'expire':7200, 'msgDevice':self.pushDev, 'msgSupLinkUrl':'', 'msgSupLinkTitle':''}
                                    alertPlugin.executeAction("send", props=alertProps)
                                else:
                                    indigo.server.log('Watchdog : Pushover plugin not available', isError=True)
                            except:
                                indigo.server.log("Pushover send error")
                        if self.prowl:
                            # Send Prowl notification
                            try:
                                alertPlugin = indigo.server.getPlugin('com.heddings.indigo.prowl')
                                if alertPlugin.isEnabled():
                                    alertProps = {'title':title, 'message':message, 'priority':priority}
                                    alertPlugin.executeAction("notify", props=alertProps)
                                else:
                                    indigo.server.log('Watchdog : Prowl plugin not available', isError=True)
                            except:
                                indigo.server.log("Prowl send error")
                        if self.mail and self.mailAdd != "":
                            # Send email notification
                            try:
                                emailTitle = title
                                indigo.server.sendEmailTo(self.mailAdd, subject=emailTitle, body=message)
                            except:
                                indigo.server.log("Email send error")
            else:
                indigo.server.log("IP device %s (%s) not found - deleting from Watchdog list" % (device[1:], self.ipDeviceNames[device]), isError=True)
                del self.ipDeviceList[device]
                try:
                    del self.ipDeviceNames[device]
                except:
                    pass


    def clocksHaveChanged(self):
        if (datetime.datetime.now() - self.lastCheckTime) > self.almostAnHour:
            if self.dst != "DST" and bool(time.localtime().tm_isdst):
                self.dst = "DST"
                indigo.server.log("Daylight Saving Time is now active")
                self.lastCheckTime = datetime.datetime.now()
                return True
        elif (self.lastCheckTime - datetime.datetime.now()) > self.almostAnHour:
            if self.dst != "GMT" and not bool(time.localtime().tm_isdst):
                self.dst = "GMT"
                indigo.server.log("Daylight Saving Time is now inactive")
                self.lastCheckTime = datetime.datetime.now()
                return True
        else:
            self.lastCheckTime = datetime.datetime.now()
            return False



    ########################################
    # Menu Item functions
    ######################

    def addDevice(self, action, actionID):
        errorDict = indigo.Dict()
        for Item in action["devId"]:
            try:
                if Item == "":
                    errorDict["devId"] = "Please select one or more devices from the list"
                    errorDict["showAlertText"] = "Please select one or more devices from the list"
                    return (False, action, errorDict)
                watchMins = action["watchMins"] or 0
                if int(watchMins) < 1:
                    errorDict["watchMins"] = "Timeout must be 1 minute or more"
                    errorDict["showAlertText"] = "Timeout must be 1 minute or more"
                    return (False, action, errorDict)
                self.deviceList["D"+Item] = int(watchMins)
                self.deviceHealth["D"+Item] = 1
                dPriority = action["nPriority"] or 0
                if -2 > int(dPriority) > 2:
                    errorDict["nPriority"] = "Priority must be between -2 and 2"
                    errorDict["showAlertText"] = "Priority must be between -2 and 2"
                    return (False, action, errorDict)
                self.devicePriority["D"+Item] = dPriority
                dev = indigo.devices[int(Item)]
                self.deviceNames["D"+Item] = dev.name
                indigo.server.log(dev.name+" added to monitored devices list with a timeout of "+watchMins+" minutes and priority of "+dPriority)
                self.pluginPrefs["deviceList"] = self.deviceList
                self.pluginPrefs["devicePriority"] = self.devicePriority
                self.pluginPrefs["deviceNames"] = self.deviceNames
                self.checkDevices()
                addError = False
            except:
                indigo.server.log("Error when trying to add %s" % dev.name, isError=True)
                addError = True
        if addError:
            return False
        else:
            return True


    def editDevice(self, action, actionID):
        errorDict = indigo.Dict()
        try:
            devId = action["devId"]
            if devId == "":
                errorDict["devId"] = "Please select a device from the list"
                errorDict["showAlertText"] = "Please select a device from the list"
                return (False, action, errorDict)
            watchMins = action["watchMins"] or 0
            if int(watchMins) < 1:
                errorDict["watchMins"] = "Timeout must be 1 minute or more"
                errorDict["showAlertText"] = "Timeout must be 1 minute or more"
                return (False, action, errorDict)
            self.deviceList["D"+devId] = int(watchMins)
            self.deviceHealth["D"+devId] = 1
            dPriority = action["nPriority"] or 0
            if -2 > int(dPriority) > 2:
                errorDict["nPriority"] = "Priority must be between -2 and 2"
                errorDict["showAlertText"] = "Priority must be between -2 and 2"
                return (False, action, errorDict)
            self.devicePriority["D"+devId] = dPriority
            dev = indigo.devices[int(devId)]
            indigo.server.log(dev.name+" edited with timeout of "+watchMins+" minutes and priority of "+dPriority)
            self.pluginPrefs["deviceList"] = self.deviceList
            self.pluginPrefs["devicePriority"] = self.devicePriority
            self.pluginPrefs["deviceNames"] = self.deviceNames
            self.checkDevices()
            return True
        except:
            indigo.server.log("Error when trying to edit device", isError=True)
            return False


    def removeDevice(self, action, actionID):
        errorDict = indigo.Dict()
        try:
            devId = action["devId"]
            if devId == "":
                errorDict["devId"] = "Please select a device from the list"
                errorDict["showAlertText"] = "Please select a device from the list"
                return (False, action, errorDict)
            del self.deviceList["D"+devId]
            del self.deviceHealth["D"+devId]
            del self.deviceNames["D"+devId]
            del self.devicePriority["D"+devId]
            dev = indigo.devices[int(devId)]
            indigo.server.log(dev.name+" removed from monitored devices list")
            self.pluginPrefs["deviceList"] = self.deviceList
            self.pluginPrefs["devicePriority"] = self.devicePriority
            self.pluginPrefs["deviceNames"] = self.deviceNames
            return True
        except:
            indigo.server.log("Error when trying to remove device", isError=True)
            return False


    def listDevices(self):
        indigo.server.log("  *****************************************************************")
        for device, devName in sorted(self.deviceNames.iteritems(), key=lambda key_item: (key_item[1], key_item[0])):
            try:
                dev = indigo.devices[int(device[1:])]
                deviceFound = True
            except:
                deviceFound = False
            if deviceFound:
                timeoutPeriod = datetime.timedelta(minutes=int(self.deviceList[device]))
                timeoutPeriodS = timeoutPeriod.total_seconds()
                timeoutPeriodF = '{:01}'.format(int(timeoutPeriodS / 60))
                dev = indigo.devices[int(device[1:])]
                self.devicePriority[device] = self.devicePriority[device] if device in self.devicePriority else 0
                priority = self.devicePriority[device]
                if self.deviceHealth[device] == 1:
                    timeGone = (datetime.datetime.now() - dev.lastChanged)
                    timeGoneS = timeGone.total_seconds()
                    timeLeftS = timeoutPeriodS - timeGoneS
                    timeLeftF = '{0:.1f}'.format(timeLeftS / 60)
                    errState = False
                    bang = "  "
                    hState = "is healthy: %s of %s min remaining, priority %s" % (timeLeftF, timeoutPeriodF, priority)
                else:
                    errState = False
                    bang = "! "
                    hState = "has timed out.  Timeout period is %s minutes, but device last changed %s.  Priority %s" % (timeoutPeriodF, str(dev.lastChanged), priority)
                indigo.server.log("%s%s %s" % (bang, dev.name, hState), isError=errState)
            else:
                indigo.server.log("Device %s not found - deleting from Watchdog list" % self.deviceNames[device], isError=True)
                del self.deviceList[device]
                del self.deviceHealth[device]
                del self.deviceNames[device]
                del self.devicePriority[device]
        indigo.server.log("  *****************************************************************")


    def listGeneratorE(self, filter="", valuesDict=None, typeId="", targetId=0):
        returnArray = []
        for device in self.deviceList:
            timeoutPeriod = datetime.timedelta(minutes=int(self.deviceList[device]))
            timeoutPeriodS = timeoutPeriod.total_seconds()
            timeoutPeriodF = '{:01}'.format(int(timeoutPeriodS / 60))
            dev = indigo.devices[int(device[1:])]
            returnArray.append([int(device[1:]), dev.name+" (Timeout = "+timeoutPeriodF+" min)"])
        return sorted(returnArray, key=lambda x: x[1])


    def listGeneratorD(self, filter="", valuesDict=None, typeId="", targetId=0):
        returnArray = []
        for device in self.deviceList:
            timeoutPeriod = datetime.timedelta(minutes=int(self.deviceList[device]))
            timeoutPeriodS = timeoutPeriod.total_seconds()
            timeoutPeriodF = '{:01}'.format(int(timeoutPeriodS / 60))
            dev = indigo.devices[int(device[1:])]
            returnArray.append([int(device[1:]), dev.name])
        return sorted(returnArray, key=lambda x: x[1])


    def listGeneratorF(self, filter="", valuesDict=None, typeId="", targetId=0):
        returnArray = []
        for device in self.ipDeviceList:
            dev = indigo.devices[int(device[1:])]
            returnArray.append([int(device[1:]), dev.name+" ("+self.ipDeviceList[device]+")"])
        return sorted(returnArray, key=lambda x: x[1])


    def addIpDevice(self, action, actionID):
        if self.ipMonitoring:
            errorDict = indigo.Dict()
            for Item in action["devId"]:
                try:
                    if Item == "":
                        errorDict["devId"] = "Please select one or more IP devices from the list"
                        errorDict["showAlertText"] = "Please select one or more IP devices from the list"
                        return (False, action, errorDict)
                    dev = indigo.devices[int(Item)]
                    self.ipDeviceNames["D"+Item] = dev.name
                    self.ipDeviceList["D"+Item] = dev.states["ipNumber"]
                    indigo.server.log(dev.name+" added to monitored IP devices list")
                    self.pluginPrefs["ipDeviceList"] = self.ipDeviceList
                    self.pluginPrefs["ipDeviceNames"] = self.ipDeviceNames
                    self.checkIpDevices()
                    addError = False
                except:
                    indigo.server.log("Error when trying to add IP device %s" % dev.name, isError=True)
                    addError = True
            if addError:
                return False
            else:
                return True
        else:
            indigo.server.log("Device IP monitoring is not enabled")


    def removeIpDevice(self, action, actionID):
        if self.ipMonitoring:
            errorDict = indigo.Dict()
            try:
                devId = action["devId"]
                if devId == "":
                    errorDict["devId"] = "Please select a device from the list"
                    errorDict["showAlertText"] = "Please select a device from the list"
                    return (False, action, errorDict)
                del self.ipDeviceList["D"+devId]
                del self.ipDeviceNames["D"+devId]
                dev = indigo.devices[int(devId)]
                indigo.server.log(dev.name+" removed from monitored IP devices list")
                self.pluginPrefs["ipDeviceList"] = self.deviceList
                return True
            except:
                indigo.server.log("Error when trying to remove IP device", isError=True)
                return False
        else:
            indigo.server.log("Device IP monitoring is not enabled")


    def listIpDevices(self):
        if self.ipMonitoring:
            indigo.server.log("****************************************")
            for device, devName in sorted(self.ipDeviceNames.iteritems(), key=lambda key_item: (key_item[1], key_item[0])):
                try:
                    dev = indigo.devices[int(device[1:])]
                    deviceFound = True
                except:
                    deviceFound = False
                if deviceFound:
                    dev = indigo.devices[int(device[1:])]
                    indigo.server.log("%s (%s)" % (dev.name, self.ipDeviceList[device]))
                else:
                    indigo.server.log("IP device %s not found - deleting from Watchdog list" % self.deviceNames[device], isError=True)
                    del self.ipDeviceList[device]
                    del self.ipDeviceNames[device]
            indigo.server.log("****************************************")
        else:
            indigo.server.log("Device IP monitoring is not enabled")



    #######################################
    # Action functions
    ######################

    def listDevicesAction(self, action):
        self.listDevices()


    def listIpDevicesAction(self, action):
        self.listIpDevices()

